<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index() {
        return view('app.index');
    }

    public function dashboard() {
        return view('dashboard.index');
    }
}
