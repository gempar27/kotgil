<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Bracket">
    <meta name="twitter:description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="twitter:image" content="http://themepixels.me/bracket/img/bracket-social.png">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Facebook -->
    <meta property="og:url" content="http://themepixels.me/bracket">
    <meta property="og:title" content="Bracket">
    <meta property="og:description" content="Premium Quality and Responsive UI for Dashboard.">

    <meta property="og:image" content="http://themepixels.me/bracket/img/bracket-social.png">
    <meta property="og:image:secure_url" content="http://themepixels.me/bracket/img/bracket-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!-- Meta -->
    <meta name="description" content="Rannum Coffee Space & Recruitment">
    <meta name="author" content="Rannum Space">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('dashboard.layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php if(!request()->routeIs('login*') && !request()->routeIs('register*')): ?>
        <?php echo $__env->make('dashboard.layouts.asside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('dashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="br-mainpanel  <?php if(request()->routeIs('profile*')): ?> br-profile-page <?php endif; ?>">
            <div class="pd-30">
                <h4 class="tx-gray-800 mg-b-5"><?php echo $__env->yieldContent('breadcrumb'); ?></h4>
            </div><!-- d-flex -->

            <div class="br-pagebody mg-t-5 pd-x-30">
                <?php echo $__env->yieldContent('content'); ?>
            </div><!-- br-pagebody -->
            <?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div><!-- br-mainpanel -->
    <?php else: ?>
        <?php echo $__env->yieldContent('authorization'); ?>
    <?php endif; ?>
    <?php echo $__env->make('dashboard.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\kotgil-app\resources\views/dashboard/layouts/main.blade.php ENDPATH**/ ?>