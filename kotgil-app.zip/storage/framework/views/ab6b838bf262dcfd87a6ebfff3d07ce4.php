<?php $__env->startSection('title', 'Kotgil | Transaction'); ?>
<?php $__env->startSection('breadcrumb', 'Transaction'); ?>
<?php $__env->startSection('content'); ?>
<div class="br-section-wrapper">
    <div class="table-wrapper">
        <?php if($msg = session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($msg); ?>

            </div>
        <?php elseif($msg = session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($msg); ?>

            </div>
        <?php endif; ?>
        <table id="free-lesson" class="table display responsive table-bordered">
            <thead>
                <tr>
                    <th class="wd-5p text-center">No</th>
                    <th class="wd-10p text-center">Nama</th>
                    <th class="wd-10p text-center">Tanggal & Waktu</th>
                    <th class="wd-10p text-center">ID Transaksi</th>
                    <th class="wd-20p text-center">Lesson</th>
                    <th class="wd-20p text-center">Tipe Pembayaran</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1.</td>
                    <td>Gwenchanayo</td>
                    <td>Gwenchanayo</td>
                    <td>Gwenchanayo</td>
                    <td>Gwenchanayo</td>
                    <td>Gwenchanayo</td>
                </tr>
            </tbody>
        </table>
    </div><!-- table-wrapper -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kotgil-app\resources\views/dashboard/transaction/index.blade.php ENDPATH**/ ?>