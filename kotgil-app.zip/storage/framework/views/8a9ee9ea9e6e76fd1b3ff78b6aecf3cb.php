    <!-- vendor css -->
    <link href="<?php echo e(asset('admin_assets/lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/jquery-switchbutton/jquery.switchButton.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/rickshaw/rickshaw.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/chartist/chartist.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('admin_assets/lib/highlightjs/github.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/bracket.css')); ?>">
    
    <link href="<?php echo e(asset('admin_assets/lib/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<?php /**PATH C:\xampp\htdocs\kotgil-app\resources\views/dashboard/layouts/links.blade.php ENDPATH**/ ?>