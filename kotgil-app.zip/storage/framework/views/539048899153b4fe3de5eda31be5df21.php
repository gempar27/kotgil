<link href="<?php echo e(asset('app_assets/css/vendor/bootstrap.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('app_assets/css/vendor/fontawesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app_assets/css/vendor/brands.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app_assets/css/vendor/regular.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app_assets/css/vendor/solid.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app_assets/css/vendor/swiper-bundle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('app_assets/css/style.css')); ?>">
<?php /**PATH C:\xampp\htdocs\kotgil-app\resources\views/app/layouts/links.blade.php ENDPATH**/ ?>