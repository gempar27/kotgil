<?php $__env->startSection('title', 'Kotgil | Tambah Free Lesson'); ?>
<?php $__env->startSection('breadcrumb', 'Tambah Free Lesson'); ?>
<?php $__env->startSection('content'); ?>
    <div class="form-layout form-layout-1 card">
        <form action="#" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row mg-b-25">
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="form-control-label" for="judul">Judul<span class="tx-danger">*</span></label>
                        <input class="form-control" type="text" id="judul" name="judul" required
                            value="<?php echo e(old('judul')); ?>">
                        <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span role="alert">
                                <small><strong class="text-danger"><?php echo e($message); ?></strong></small>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div><!-- col-4 -->
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="form-control-label" for="image">Upload Foto<span class="tx-danger">* </span><small
                                class="show-file-name"></small></label>
                        <label class="custom-file col-12">
                            <input type="file" class="custom-file-input" id="image" name="image"
                                accept=".jpg,.jpeg,.png,.jfif" required style="cursor: pointer;"
                                onchange="displayFileName()">
                            <span class="custom-file-control custom-file-control-inverse"></span>
                        </label>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span role="alert">
                                <small><strong class="text-danger"><?php echo e($message); ?></strong></small>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div><!-- col-4 -->
                <div class="col-lg-12">
                    <div class="form-group">
                        <label class="form-control-label" for="video">Upload Video<span class="tx-danger">* </span><small
                                class="show-file-name"></small></label>
                        <label class="custom-file col-12">
                            <input type="file" class="custom-file-input" id="video" name="video"
                                accept=".mp4" required style="cursor: pointer;">
                            <span class="custom-file-control custom-file-control-inverse"></span>
                        </label>
                        <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span role="alert">
                                <small><strong class="text-danger"><?php echo e($message); ?></strong></small>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div><!-- col-4 -->
            </div><!-- row -->
            <div class="form-layout-footer">
                <button style="cursor: pointer" type="submit" class="btn btn-info">Simpan</button>
                <button style="cursor: pointer" type="button"onclick="window.history.go('-1');"
                    class="btn btn-secondary">Cancel</button>
            </div><!-- form-layout-footer -->
        </form>
    </div><!-- form-layout -->
<?php $__env->stopSection(); ?>
<script>
    // JavaScript
    function displayFileName() {
        const fileInput = document.getElementById('image');
        const fileNameDisplay = document.querySelector('.show-file-name');

        if (fileInput.files.length > 0) {
            fileNameDisplay.textContent = fileInput.files[0].name;
        } else {
            fileNameDisplay.textContent = '';
        }
    }
</script>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kotgil-app\resources\views/dashboard/lesson/create.blade.php ENDPATH**/ ?>